RET=$(python3 -u main.py | tail -1)
RET=($RET)
echo $RET
python3 test.py ${RET[0]} ${RET[1]} | tail -1