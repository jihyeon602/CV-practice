"""
    STDIO 에 대한 grader.py 입니다.

    grader 동작에 필요한 기본적인 모듈을 불러옵니다.
    
"""

import os
import subprocess
import sys
import traceback

import imp
from io import StringIO

sys.path.append(os.getcwd())
from grader_elice_utils import EliceUtils  # isort:skip

elice_utils = EliceUtils()
elice_utils.secure_init()

"""
    
    채점에 필요한 변수들을 선언, 초기화합니다.
    
"""

# Set total Score
TOTAL_SCORE = 100

# Set testcases point
TESTCASE_SCORE = {0:100}

# Set testcases Num
NUM_TESTCASES = len(TESTCASE_SCORE)

# Student score
STUDENT_SCORE = 0

# testcase dir
INPUT_DIR = '.elice/input/'
OUTPUT_DIR = '.elice/output/'

ANSWER_COMMENT = [
    "정답입니다! 셔플링을 잘 했습니다."
]

WRONG_COMMENT = [
    "오답입니다. 셔플링을 하여 loss가 줄어들었는지 확인해보세요."
]

def send_start_message():
    elice_utils.secure_send_grader("채점을 시작합니다. 학습을 위한 시간이 소요될 수 있습니다.\n")
    elice_utils.secure_send_grader("=" * 32 + "\n")

def send_end_message(user_point):
    elice_utils.secure_send_grader("="*32 + "\n")
    elice_utils.secure_send_grader("채점을 마쳤습니다.\n")
    elice_utils.secure_send_grader(f"총 점수: {user_point} / {TOTAL_SCORE}\n")
    elice_utils.secure_send_score(user_point)
    sys.exit(1)

def validate_testcase_file():
    # list the input and output data
    input_data = [x for x in os.listdir(INPUT_DIR) if x.endswith('.txt')]
    output_data = [x for x in os.listdir(OUTPUT_DIR) if x.endswith('.txt')]

    # validate if input data have matching output
    matching = True
    for i in range(1, NUM_TESTCASES + 1):
        input_file = '%d.txt' % i
        output_file = '%d.txt' % i

        if input_file not in input_data:
            print("Error: input [%s] does not exist" % input_file)
            matching = False
        if output_file not in output_data:
            print("Error: output [%s] does not exist" % output_file)
            matching = False
    if not matching:
        sys.exit(1)
        
    return input_data, output_data


try:
    send_start_message()
#     input_data, output_data = validate_testcase_file()
    import main
    import solution
    
    student_result = 0
    
    if main.results_no_shuffle is not None and main.results_shuffle is not None:
        student_result = main.results_no_shuffle.history['loss'][-1] - main.results_shuffle.history['loss'][-1]
    
    for testcase_index in range(0, NUM_TESTCASES):
#         input_file = '%d.txt' % int(testcase_index+1)
        
#         input_text = subprocess.run(['cat', '%s%s' % (INPUT_DIR, input_file)],
#                                     stdout=subprocess.PIPE).stdout
        
#         result = subprocess.run(['/bin/bash', '.elice/forgrading.sh'],
#                                 input=input_text,
#                                 stdout=subprocess.PIPE)
#         student_result = result.stdout.decode('utf-8')
#         student_result = student_result.strip()
#         answer = '\n'.join(open('%s%s' % (OUTPUT_DIR, input_file)).readlines())
#         answer = answer.strip().replace('\n\n', '\n')
        
#         print(student_result)
#         print(answer)
    
        if student_result > 0:
            STUDENT_SCORE += TESTCASE_SCORE[testcase_index]
            elice_utils.secure_send_grader(f'Case {testcase_index+1}. {ANSWER_COMMENT[testcase_index]} (+{TESTCASE_SCORE[testcase_index]})\n')
        else:
            elice_utils.secure_send_grader(f'Case {testcase_index+1}. {WRONG_COMMENT[testcase_index]} (+0)\n')
            pass


    send_end_message(STUDENT_SCORE)

    elice_utils.secure_send_score(total_score)
except Exception as err:
    elice_utils.secure_send_grader('Internal Error:\n%s\n' % str(err))
    elice_utils.secure_send_score(0)
    sys.exit(1)