import sys

"""
채첨용 소스.
셔플 유무에 따른 loss 비교를 bash에서 하려고 하는데
가상시스템에 bc 명령어가 없어서 스크립트 사용함
"""

print(sys.argv[1])
print(sys.argv[2])
if float(sys.argv[1]) > float(sys.argv[2]):
    print("SUCCESS")
else:
    print("FAIL")